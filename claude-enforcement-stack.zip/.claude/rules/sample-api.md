# API Routes — Sample Rules
# SAMPLE: Replace globs, rename file, and rewrite rules for your project.

globs: src/api/**, src/routes/**, app/routes/**

- All routes must validate input at the boundary (request params, body, headers).
- Use the project's standard error response format. Don't return raw exceptions.
- Auth/authz checks happen in middleware or decorators, not inline in handlers.
- Database access goes through the service/repository layer, not direct queries in handlers.
- Status code semantics: 400 bad input, 401 unauthenticated, 403 forbidden, 404 not found, 422 validation, 500 internal.
- Pagination and rate limiting are handled at the middleware/framework level where available.
