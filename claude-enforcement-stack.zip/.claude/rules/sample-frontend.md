# Frontend — Sample Rules
# SAMPLE: Replace globs, rename file, and rewrite rules for your project.

globs: src/components/**, src/pages/**, app/**/*.tsx, app/**/*.vue

- Components must be accessible (ARIA attributes, keyboard navigation, focus management).
- Shared state goes through the project's chosen pattern (store/context/signals), not ad-hoc local state.
- API calls go through a centralized client/service layer, not raw fetch in components.
- Error and loading states must be handled explicitly in every data-fetching component.
- Styles follow the project's convention (CSS modules / Tailwind / styled-components). Don't mix approaches.
- No hardcoded user-facing strings — use the i18n system if one exists.
