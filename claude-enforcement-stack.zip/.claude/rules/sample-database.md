# Database / Storage — Sample Rules
# SAMPLE: Replace globs, rename file, and rewrite rules for your project.

globs: src/db/**, src/models/**, src/repositories/**

- All queries must be parameterized. No string interpolation in SQL.
- Multi-tenant queries must include tenant scoping (org_id, team_id, etc.).
- Migrations must be reversible. Include both up and down.
- Use the ORM/query builder for standard CRUD. Raw SQL only for complex analytics or performance-critical paths.
- Index changes require a performance justification comment.
- Connection pooling is managed at the application level, not per-query.
