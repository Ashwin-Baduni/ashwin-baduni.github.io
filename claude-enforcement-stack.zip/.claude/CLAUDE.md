# CLAUDE.md -- [Project Name] Instructions

---

# Project Context

<!-- REPLACE: Describe what this project is, its architecture, key technologies,
     and how the major pieces connect. 2-3 paragraphs max. Example: -->

[Project Name] is a [domain] application that [core purpose]. Built with [key technologies].

**Architecture:**
- **[Component A]** (`path/to/a`): [what it does]
- **[Component B]** (`path/to/b`): [what it does]
- **[Component C]** (`path/to/c`): [what it does]

---

# Controlled Execution Protocol

Your primary goal is correctness, safety and traceability.
You must never guess. You must prove every claim with code, data, or logs.

---

## GLOBAL RULES (Non-Negotiable)

### 1. 5-Step Thinking
For responses involving **code changes, architectural decisions, or debugging**:
- **Step 1 -- Initial Answer:** propose best solution/plan from current evidence.
- **Step 2 -- Potential Errors/Gaps:** list risks, unknowns, weak assumptions.
- **Step 3 -- Research:** individually find/search the root-causes of these errors/gaps from Step 2 and formulate the best solutions for each.
- **Step 4 -- Verification:** confirm each item with logs/tests/code inspection.
- **Step 5 -- Revised Final Answer:** updated solution based on verified evidence.

**Skip for:** trivial factual queries (git status, file reads, simple lookups, direct questions with clear answers).

### 2. No Bandage Fixes
- Always prefer root-cause elimination over superficial patches.
- If a temporary fix is necessary, label it with `# TEMPORARY:` comment explaining the root cause and intended permanent fix.

---

## Git Policy
- Local commits (`git commit`) are allowed when requested.
- NEVER run `git push`, `git fetch`, or any command that touches remote repositories.
<!-- ADJUST: If your team wants Claude to push, change this. -->

---

## Coding Conventions

<!-- REPLACE: Your project's language, framework, testing, and naming conventions. -->

- **Language**: [e.g., Python 3.11+, TypeScript 5+, Go 1.22+]
- **Testing**: [e.g., pytest, vitest, go test]; tests live in [location]
- **Imports**: [e.g., stdlib > third-party > local, one blank line between groups]
- **Package structure**: [e.g., src/ layout, monorepo with packages/]
- **Naming**: [e.g., snake_case functions, PascalCase classes, UPPER_CASE constants]

---

## Proactive Plugin Usage

<!-- ADJUST: Keep only the plugins/skills you have installed.
     Remove sections for plugins you don't use. -->

Use installed plugins automatically without being asked. The rules below are MANDATORY.

### After Writing or Modifying Code
- **superpowers:verification-before-completion**: ALWAYS run verification (tests, lints, build) before claiming work is done. No "should work" -- show evidence.
- **superpowers:test-driven-development**: When implementing features or fixing bugs, write failing tests FIRST. No exceptions unless user explicitly says otherwise.

### Before Starting Feature Work
- **superpowers:brainstorming**: Use before any non-trivial feature (new module, architecture change, multi-file refactor). Skip for simple single-file edits or quick fixes.
- **superpowers:writing-plans**: After brainstorming produces an approved design, create a plan before implementation.

### For Implementation
- **superpowers:dispatching-parallel-agents**: When facing 2+ independent tasks, dispatch focused agents in parallel.
- **superpowers:subagent-driven-development**: When executing implementation plans with independent tasks, dispatch per-task subagents with two-stage review.

### For Debugging
- **superpowers:systematic-debugging**: Use for ANY bug, test failure, or unexpected behavior. No guessing -- root cause first.

### After Completing Major Work
- **superpowers:requesting-code-review**: After completing a feature or significant bugfix, proactively offer to run code review.
- **superpowers:finishing-a-development-branch**: When implementation is complete and tests pass, present integration options.

### For Frontend / UI Work
<!-- Remove this section if your project has no frontend -->
- **impeccable:frontend-design**: Load before any frontend implementation.
- **impeccable:audit**: Run after completing any UI component or page.
- **impeccable:polish**: Suggest a polish pass before declaring UI work complete.

### For PR / Code Review
- **code-review**: When user asks to review a PR or when completing work that will become a PR.

### Cross-Session Memory
<!-- Remove this section if claude-mem is not installed -->
- **claude-mem:mem-search**: Check persistent memory when user references previous sessions or past decisions.
- **claude-mem:smart-explore**: Prefer over raw file reads for structural code understanding.
