#!/usr/bin/env bash
# SubagentStop hook: verify subagent completion claims.
# Fires when a subagent finishes. Reminds the parent to verify.

echo '{"systemMessage":"Subagent completed. Before trusting its report: (1) Verify claimed files actually exist. (2) Verify claimed test counts by running tests yourself. (3) Check for silent skips or partial implementations. (4) Do not relay subagent claims without evidence."}'
