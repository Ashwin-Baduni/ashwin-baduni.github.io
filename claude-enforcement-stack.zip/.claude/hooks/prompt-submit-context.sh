#!/usr/bin/env bash
# UserPromptSubmit hook: auto-reinforces CLAUDE.md rules per task type.
# Silent on ack prompts. Injects the specific CLAUDE.md mandates so the
# user never has to manually remind about plugins, 5-step, TDD, etc.
#
# CUSTOMIZE: Change keyword patterns, CLAUDE.md section references, and
# plugin names to match your project's rules and installed plugins.

set -euo pipefail

INPUT=$(cat)
PROMPT=$(echo "$INPUT" | jq -r '.prompt // ""' 2>/dev/null || echo "")
PROMPT_LC=$(printf '%s' "$PROMPT" | tr '[:upper:]' '[:lower:]')

# Ignore low-signal acknowledgements and continuations.
if echo "$PROMPT_LC" | grep -Eq '^[[:space:]]*(yes|yeah|yep|ok|okay|continue|go ahead|looks good|lgtm|please|pls|do it|ship it|sounds good|pass 2 then\??)[[:space:]]*$'; then
  exit 0
fi

# ── Category: Bug / fix work ────────────────────────────────────────
# CLAUDE.md refs: 5-Step Thinking, No Bandage Fixes, systematic-debugging
if echo "$PROMPT_LC" | grep -Eq 'bug|fix|broken|failing|failure|error|regression|not working|issue|crash'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — Bug work rules:\n• 5-Step Thinking (§1): propose → list gaps → research each → verify with evidence → revised answer. Do not skip steps.\n• No Bandage Fixes (§2): root-cause elimination, not patches. If temporary, mark with # TEMPORARY: comment.\n• Plugin: use superpowers:systematic-debugging — reproduce first, isolate the exact layer, then patch.\n• Verification: run tests and show green output before claiming fixed."
    }
  }'
  exit 0
fi

# ── Category: Frontend / UI work ────────────────────────────────────
# CLAUDE.md refs: Frontend plugins, verification
if echo "$PROMPT_LC" | grep -Eq 'frontend|ui|ux|react|vue|svelte|component|css|styling|responsive|layout'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — Frontend work rules:\n• Plugin: load impeccable:frontend-design BEFORE writing any UI code.\n• Plugin: run impeccable:audit after completing any component or page.\n• Plugin: suggest impeccable:polish before declaring UI work complete.\n• 5-Step Thinking (§1): applies to frontend architecture decisions too.\n• Verification: test the live state of the UI first. Check accessibility, error/loading states, and project styling convention."
    }
  }'
  exit 0
fi

# ── Category: Feature / implementation work ─────────────────────────
# CLAUDE.md refs: brainstorming, planning, TDD, parallel agents
if echo "$PROMPT_LC" | grep -Eq 'implement|build|add|create|feature|endpoint|integrate|refactor'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — Feature work rules:\n• Plugin: superpowers:brainstorming BEFORE non-trivial features (new module, architecture change, multi-file refactor).\n• Plugin: superpowers:writing-plans after brainstorming produces an approved design.\n• Plugin: superpowers:test-driven-development — write failing tests FIRST, then implement.\n• Plugin: superpowers:dispatching-parallel-agents for 2+ independent tasks.\n• 5-Step Thinking (§1): propose → gaps → research → verify → revised answer.\n• Inspect existing code patterns before writing new code. Follow established conventions."
    }
  }'
  exit 0
fi

# ── Category: Review / PR work ──────────────────────────────────────
if echo "$PROMPT_LC" | grep -Eq 'review|pr |pull request|merge|diff|check my'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — Review rules:\n• Plugin: use code-review for PR or completed work review.\n• Plugin: superpowers:verification-before-completion — run tests, show green output. No \"should work\" claims.\n• Plugin: superpowers:finishing-a-development-branch when implementation is complete and tests pass."
    }
  }'
  exit 0
fi

# ── Category: Planning / architecture ───────────────────────────────
if echo "$PROMPT_LC" | grep -Eq 'plan|architect|design|how should|approach|strategy|phase|roadmap'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — Planning rules:\n• 5-Step Thinking (§1): mandatory for architectural decisions.\n• Plugin: superpowers:brainstorming before creative/design work.\n• Plugin: superpowers:writing-plans for multi-step task plans.\n• Plugin: claude-mem:make-plan for non-trivial multi-step tasks with doc discovery.\n• Never guess. Prove every claim with code, data, or logs."
    }
  }'
  exit 0
fi

# ── Catch-all: any coding/development task ──────────────────────────
# Fires on general development prompts that didn't match a specific category.
# This is the safety net that prevents the user needing to repeat CLAUDE.md rules.
if echo "$PROMPT_LC" | grep -Eq 'code|function|class|module|test|deploy|config|update|change|modify|edit|write|remove|delete|move|rename|migrate'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "UserPromptSubmit",
      additionalContext: "Per CLAUDE.md — General rules active:\n• 5-Step Thinking (§1) for code changes, architecture, debugging. Skip for trivial lookups.\n• No Bandage Fixes (§2): root-cause over patches.\n• Use plugins proactively — do not wait to be asked. See Proactive Plugin Usage in CLAUDE.md.\n• Verification: run tests before claiming done."
    }
  }'
  exit 0
fi

exit 0
