#!/usr/bin/env bash
# Stop hook: final readiness gate.
# Fires when Claude is about to stop working.
# Emits a system message reminding to verify before claiming done.

echo '{"systemMessage":"Before finalizing: (1) Did you run tests and show green output? (2) Are protected directories untouched? (3) Did subagents actually complete what they claimed? Verify files exist. (4) Does implementation match the approved plan?"}'
