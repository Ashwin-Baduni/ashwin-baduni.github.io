#!/usr/bin/env bash
# PreToolUse guard for Write/Edit/MultiEdit.
# Reads hook event JSON from stdin, extracts file_path, applies rules.
#
# CUSTOMIZE: Change the path patterns and import patterns for your project.
#
# Rule 1: BLOCK edits to protected directories (hard deny).
# Rule 2: WARN on direct database/storage imports bypassing the service layer.
# Rule 3: WARN on schema/contract file edits (high-impact changes).

set -euo pipefail

INPUT=$(cat)

# Extract file_path from the tool input JSON
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.filePath // ""' 2>/dev/null || echo "")
NEW_TEXT=$(echo "$INPUT" | jq -r '[.tool_input.content?, .tool_input.new_string?, (.tool_input.edits[]?.new_string?)] | map(select(type == "string")) | join("\n")' 2>/dev/null || echo "")

if [ -z "$FILE_PATH" ]; then
  exit 0
fi

# Rule 1: Block protected directory edits.
# CUSTOMIZE: Change these paths to your vendored/generated/locked directories.
# Examples: vendor/, third_party/, generated/, node_modules/src/
if echo "$FILE_PATH" | grep -Eq '(vendor|third_party|generated)/'; then
  echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"BLOCKED: This directory is read-only. Vendored and generated code must not be modified. All custom behavior must live outside protected directories."}}'
  exit 0
fi

# Rule 2: Warn on direct DB/storage imports in handler/controller files.
# CUSTOMIZE: Change the file pattern and import patterns for your project.
# This catches code that bypasses the service/repository layer.
if echo "$FILE_PATH" | grep -Eq '(handlers|controllers|routes|views)/.*\.(py|ts|js)$' \
  && echo "$NEW_TEXT" | grep -Eq 'import.*\b(prisma|knex|sequelize|sqlalchemy|mongoose)\b|from.*\bmodels\b.*import'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: "allow",
      additionalContext: "WARNING: Direct database/ORM import detected in a handler file. Handlers should use the service/repository layer for data access, not import database clients or models directly."
    }
  }'
  exit 0
fi

# Rule 3: Warn on schema/contract/migration edits.
# CUSTOMIZE: Change the pattern to match your schema, migration, or contract files.
if echo "$FILE_PATH" | grep -Eq '(schema|migrations?|contracts?|proto|\.graphql|openapi)\b'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: "allow",
      additionalContext: "CAUTION: Editing a schema/contract/migration file. These changes can affect many consumers. Check backward compatibility, run migration tests, and update any dependent code."
    }
  }'
  exit 0
fi

# Default: allow silently
exit 0
