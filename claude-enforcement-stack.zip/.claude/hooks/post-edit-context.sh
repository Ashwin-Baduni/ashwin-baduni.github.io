#!/usr/bin/env bash
# PostToolUse hook for Write/Edit/MultiEdit.
# Emits file-class-specific reminders after edits.
#
# CUSTOMIZE: Change the path patterns and reminder text for your project's areas.
# Add one if-block per major code area. First match wins.

set -euo pipefail

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.filePath // .tool_response.file_path // .tool_response.filePath // ""' 2>/dev/null || echo "")

if [ -z "$FILE_PATH" ]; then
  exit 0
fi

# Area: API routes / handlers
# CUSTOMIZE: path pattern and reminder for your API layer
if echo "$FILE_PATH" | grep -Eq '(routes|handlers|controllers|endpoints)/'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PostToolUse",
      additionalContext: "API layer edited. Verify: input validation at boundary, proper auth checks, correct status codes, and error response format consistency."
    }
  }'
  exit 0
fi

# Area: Database / storage / models
# CUSTOMIZE: path pattern and reminder for your data layer
if echo "$FILE_PATH" | grep -Eq '(models|db|repositories|storage|migrations)/'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PostToolUse",
      additionalContext: "Data layer edited. Verify: parameterized queries, tenant/org scoping on multi-tenant queries, migration reversibility, and index impact."
    }
  }'
  exit 0
fi

# Area: Frontend components / pages
# CUSTOMIZE: path pattern and reminder for your frontend
if echo "$FILE_PATH" | grep -Eq '(components|pages|views|app)/.*\.(tsx|jsx|vue|svelte)$'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PostToolUse",
      additionalContext: "Frontend file edited. Verify: accessibility (ARIA, keyboard nav), error/loading states handled, API calls through service layer, and styling follows project convention."
    }
  }'
  exit 0
fi

# Area: Configuration / environment
# CUSTOMIZE: path pattern for your config files
if echo "$FILE_PATH" | grep -Eq '(config|\.env|settings)\b'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PostToolUse",
      additionalContext: "Config file edited. Verify: no secrets committed, environment-specific values use env vars, and changes are documented if they affect deployment."
    }
  }'
  exit 0
fi

exit 0
