# Claude Code Enforcement Stack

A portable hook-based safety and context system for Claude Code. Copy this `.claude/` directory into any repo and adapt it for that project.

---

## Quick Start (For Claude in a New Repo)

If you've been asked to adapt this enforcement stack for a new project, follow the **Adaptation Guide** section below. You'll need to:

1. Copy this `.claude/` directory to the target repo root
2. Customize `settings.local.json` (SessionStart message)
3. Customize the 5 hook scripts for the project's file structure
4. Rewrite `CLAUDE.md` for the project's domain and conventions
5. Create new rules files in `rules/` for each major code area
6. Run `VERIFY_SETUP.md` to confirm everything works

---

## Architecture: 6-Phase Hook System

Hooks fire at specific points in a Claude Code session. Each phase has a distinct purpose.

```
Session loads
  |
  v
[1. SessionStart] ---- emits project invariants (once)
  |
User types message
  |
  v
[2. UserPromptSubmit] - detects intent keywords, adds contextual guidance
  |
Claude picks a tool
  |
  v
[3. PreToolUse] ------- BLOCKS protected edits, WARNS on risky patterns
  |
Tool executes
  |
  v
[4. PostToolUse] ------ emits file-class reminders after edits
  |
Claude finishes
  |
  v
[5. Stop] ------------- readiness checklist before session ends
[6. SubagentStop] ----- verification reminder when a subagent finishes
```

### Design Principles

- **Block destructive, advise constructive.** Hard deny only for irreversible mistakes (editing vendored/protected code). Everything else is advisory.
- **Silent on routine.** Ack prompts ("yes", "ok", "continue") produce no hook output. No fatigue.
- **File-class matching.** PostToolUse reminders fire only for the specific area being edited, not on every file.
- **Keyword gating.** UserPromptSubmit only emits when it detects specific intent (bug, feature, frontend), not on every message.

---

## File Reference

```
.claude/
  CLAUDE.md ............... Project instructions template (auto-loaded by Claude Code).
                            Contains: project context, global rules, coding conventions,
                            plugin usage, git policy.
  settings.local.json ..... Hook configuration. Defines all 6 phases, matchers,
                            commands, status messages. THE entry point.
  hooks/
    pre-edit-guard.sh ..... PreToolUse: blocks protected dirs, warns on risky imports
                            and contract edits. Matcher: Write|Edit|MultiEdit.
    post-edit-context.sh .. PostToolUse: file-class-specific reminders after edits.
                            Matcher: Write|Edit|MultiEdit.
    prompt-submit-context.sh  UserPromptSubmit: intent detection (bug/feature/frontend),
                            silent on ack prompts.
    stop-readiness.sh ..... Stop: 4-point readiness checklist.
    subagent-stop.sh ...... SubagentStop: 4-point subagent verification reminder.
  rules/
    sample-*.md ........... Sample rules for common code areas (API, database, frontend).
                            Rename, rewrite, and add more for your project.
  docs/
    README.md ............. This file.
    plugins.md ............ Complete reference of all installed plugins with install
                            commands, skill lists, and settings.json snapshot.
    adrsample.md .......... ADR (Architecture Decision Record) template.
    VERIFY_SETUP.md ....... Verification guide (quick shell + full live session).
                            Needs updating after customization.
```

---

## Adaptation Guide

### Step 1: Understand the Target Project

Before customizing anything, answer these questions about the target repo:

- **What directories are read-only / protected?** (vendored deps, generated code, third-party)
- **What are the major code areas?** (backend, frontend, API, storage, tools, tests)
- **What file patterns are important?** (e.g., `src/**/routes.ts`, `**/models.py`)
- **What are the project's key invariants?** (e.g., "all DB access through ORM", "no direct SQL")
- **What coding conventions apply?** (language, style, testing framework, naming)
- **What workflow keywords matter?** (beyond the defaults: bug, feature, frontend)

### Step 2: Customize `settings.local.json`

The SessionStart hook is an inline JSON command. Update the `additionalContext` string:

```json
"command": "echo '{\"hookSpecificOutput\":{\"hookEventName\":\"SessionStart\",\"additionalContext\":\"YOUR PROJECT loaded. Key invariants: (1) ... (2) ... (3) ...\"}}'",
```

Write 3-6 short invariants that are the most critical rules for your project. These appear at the top of every session as a system reminder.

The rest of settings.local.json (hook command paths, matchers) is generic and usually doesn't need changes. The `$CLAUDE_PROJECT_DIR` variable auto-resolves.

### Step 3: Customize `hooks/pre-edit-guard.sh`

This is the most important hook. It has three rules to customize:

**Rule 1 — Protected directory (hard block):**
```bash
# Change this pattern to YOUR protected directories
if echo "$FILE_PATH" | grep -Eq '(vendor|third_party|generated)/'; then
```
Add more directories by extending the regex: `(vendor|third_party|generated|your_dir)/`

**Rule 2 — Risky import patterns (warning):**
```bash
# Change the file path pattern and import patterns
if echo "$FILE_PATH" | grep -Eq '(handlers|controllers|routes|views)/.*\.(py|ts|js)$' \
  && echo "$NEW_TEXT" | grep -Eq 'import.*\b(prisma|knex|sequelize|sqlalchemy|mongoose)\b|from.*\bmodels\b.*import'; then
```
This catches code that bypasses the service/repository layer. The pattern matches both direct ORM client imports and model imports in handler files.

**Rule 3 — Sensitive file edits (warning):**
```bash
# Change to your sensitive files (schemas, contracts, migrations)
if echo "$FILE_PATH" | grep -Eq '(schema|migrations?|contracts?|proto|\.graphql|openapi)\b'; then
```

### Step 4: Customize `hooks/post-edit-context.sh`

Add one `if` block per major code area. Each block matches a file path pattern and emits a reminder.

Pattern:
```bash
if echo "$FILE_PATH" | grep -Eq 'your/path/pattern/'; then
  jq -n '{
    hookSpecificOutput: {
      hookEventName: "PostToolUse",
      additionalContext: "YOUR REMINDER: things to verify after editing this area."
    }
  }'
  exit 0
fi
```

The sample covers 4 areas: API routes, database/storage, frontend components, and config files. Add or replace as needed.

### Step 5: Customize `hooks/prompt-submit-context.sh`

This hook auto-reinforces CLAUDE.md rules per task type. Each category injects the specific sections, plugins, and mandates that apply — so the user never has to manually remind about 5-step thinking, TDD, plugins, etc.

Four things to customize:

1. **Ack filter** (line 16): The regex of low-signal prompts to ignore. Usually fine as-is.
2. **Keyword categories** (6 built-in: bug, frontend, feature, review, planning, catch-all coding): Change the `grep -Eq` patterns for your domain.
3. **CLAUDE.md references**: Each category cites specific CLAUDE.md sections (`§1`, `§2`) and plugin names. Update these to match your CLAUDE.md and installed plugins.
4. **Category order matters**: First match wins. Bug/frontend/feature are specific and come first. The catch-all coding category is the safety net at the end.

### Step 6: Customize `hooks/stop-readiness.sh` and `hooks/subagent-stop.sh`

These are generic and usually work as-is. Customize the checklist items if needed.

### Step 7: Rewrite `CLAUDE.md`

The template `CLAUDE.md` has placeholder sections. Fill in:

| Section | What to do |
|---------|-----------|
| Project Context | Replace with your project description, architecture |
| 5-Step Thinking | Keep as-is (generic) |
| No Bandage Fixes | Keep as-is (generic) |
| Git Policy | Adjust push/fetch rules per team |
| Coding Conventions | Replace with your language/framework |
| Proactive Plugin Usage | Keep installed plugins, remove others (see `docs/plugins.md`) |

### Step 8: Create Rules Files

Replace the `sample-*.md` files in `rules/` with project-specific rules. Format:

```markdown
# Area Name -- Short Description
# Replace globs and rules for your project.

globs: path/to/area/**

- Convention 1: concrete, actionable
- Convention 2: what to use, what NOT to use
- Convention 3: error handling expectations
```

The `globs:` line determines when Claude auto-loads these rules. Create one file per major code area.

### Step 9: Update `VERIFY_SETUP.md`

Adapt the verification tests to match your new paths, patterns, and hook behaviors.

### Step 10: Verify

Run the Quick Verification (shell one-liner in VERIFY_SETUP.md) to confirm everything works, then run a live Full Verification session.

---

## Hook Script Conventions

All hook scripts follow these conventions:

1. **Shebang:** `#!/usr/bin/env bash`
2. **Strict mode:** `set -euo pipefail`
3. **Input:** Read JSON from stdin via `INPUT=$(cat)`
4. **Extraction:** Use `jq` to extract fields (file_path, prompt, etc.)
5. **Output:** Either empty (allow silently) or a JSON object with `hookSpecificOutput`
6. **Exit:** Always `exit 0` — non-zero exits cause Claude Code to report hook errors

### Permission Decisions (PreToolUse only)

```json
// Hard block:
{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"WHY"}}

// Allow with warning:
{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","additionalContext":"WARNING TEXT"}}
```

### Context Injection (PostToolUse, UserPromptSubmit)

```json
{"hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"YOUR REMINDER"}}
```

### System Messages (Stop, SubagentStop)

```json
{"systemMessage":"YOUR CHECKLIST"}
```

---

## Requirements

- **jq**: Required by hook scripts for JSON parsing. Install: `sudo apt install jq` / `brew install jq`
- **bash**: All scripts use bash (not sh/zsh)
- **Executable permissions**: All `.sh` files must be `chmod +x`
- **Claude Code**: Hooks only fire inside Claude Code sessions
- **Plugins**: See `docs/plugins.md` for the full plugin list and install instructions
