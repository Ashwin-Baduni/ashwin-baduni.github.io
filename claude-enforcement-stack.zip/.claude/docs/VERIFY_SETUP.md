# Enforcement Stack — Verification Guide

Two verification methods: **Quick** (shell one-liner) and **Full** (manual Claude Code session).

---

## Quick Verification (Shell)

Run from the repo root. Tests JSON validity, script syntax, permissions, jq, and functional behavior.

```bash
bash -c '
PASS=0; FAIL=0; report() { if [ "$1" = "PASS" ]; then ((PASS++)); else ((FAIL++)); fi; printf "  %-40s %s\n" "$2" "$1"; }

echo "=== Hook System Verification ==="
echo ""

# 1. JSON validity
python3 -m json.tool .claude/settings.local.json >/dev/null 2>&1
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "settings.local.json valid JSON"

# 2. Hook count (expect 6 phases)
COUNT=$(jq -e ".hooks | keys | length" .claude/settings.local.json 2>/dev/null)
report $([[ "$COUNT" = "6" ]] && echo PASS || echo FAIL) "Hook phases registered ($COUNT/6)"

# 3. Hook phase names
KEYS=$(jq -r ".hooks | keys[]" .claude/settings.local.json 2>/dev/null | sort | tr "\n" ",")
EXPECT="PostToolUse,PreToolUse,SessionStart,Stop,SubagentStop,UserPromptSubmit,"
report $([[ "$KEYS" = "$EXPECT" ]] && echo PASS || echo FAIL) "Hook phase names match"

# 4. jq available
which jq >/dev/null 2>&1
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "jq installed"

# 5. Script permissions
ALL_EXEC=true
for f in .claude/hooks/*.sh; do [[ -x "$f" ]] || ALL_EXEC=false; done
report $($ALL_EXEC && echo PASS || echo FAIL) "All hook scripts executable"

# 6. Bash syntax
ALL_SYNTAX=true
for f in .claude/hooks/*.sh; do bash -n "$f" 2>/dev/null || ALL_SYNTAX=false; done
report $($ALL_SYNTAX && echo PASS || echo FAIL) "All hook scripts valid bash"

# 7. PreToolUse blocks protected directory
OUT=$(echo "{\"tool_input\":{\"file_path\":\"vendor/something/x.py\",\"new_string\":\"\"}}" | .claude/hooks/pre-edit-guard.sh 2>/dev/null)
echo "$OUT" | grep -q '"deny"'
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PreToolUse blocks protected directory"

# 8. PreToolUse allows normal edits
OUT=$(echo "{\"tool_input\":{\"file_path\":\"src/app/main.py\",\"new_string\":\"\"}}" | .claude/hooks/pre-edit-guard.sh 2>/dev/null)
report $([[ -z "$OUT" ]] && echo PASS || echo FAIL) "PreToolUse allows normal edits"

# 9. PreToolUse warns on direct DB import in handler
OUT=$(echo "{\"tool_input\":{\"file_path\":\"src/handlers/users.py\",\"new_string\":\"import sqlalchemy\"}}" | .claude/hooks/pre-edit-guard.sh 2>/dev/null)
echo "$OUT" | grep -q "Direct database"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PreToolUse warns on direct DB import"

# 10. PreToolUse warns on schema edit
OUT=$(echo "{\"tool_input\":{\"file_path\":\"db/migrations/001_init.py\",\"new_string\":\"\"}}" | .claude/hooks/pre-edit-guard.sh 2>/dev/null)
echo "$OUT" | grep -q "schema/contract"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PreToolUse warns on schema edit"

# 11. PostToolUse emits API context
OUT=$(echo "{\"tool_input\":{\"file_path\":\"src/routes/users.py\"}}" | .claude/hooks/post-edit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "API layer"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PostToolUse emits API context"

# 12. PostToolUse emits database context
OUT=$(echo "{\"tool_input\":{\"file_path\":\"src/models/user.py\"}}" | .claude/hooks/post-edit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "Data layer"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PostToolUse emits database context"

# 13. PostToolUse emits frontend context
OUT=$(echo "{\"tool_input\":{\"file_path\":\"src/components/Header.tsx\"}}" | .claude/hooks/post-edit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "Frontend"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PostToolUse emits frontend context"

# 14. PostToolUse emits config context
OUT=$(echo "{\"tool_input\":{\"file_path\":\"config/production.yaml\"}}" | .claude/hooks/post-edit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "Config file"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PostToolUse emits config context"

# 15. PromptSubmit ignores acks
OUT=$(echo "{\"prompt\":\"yes\"}" | .claude/hooks/prompt-submit-context.sh 2>/dev/null)
report $([[ -z "$OUT" ]] && echo PASS || echo FAIL) "PromptSubmit ignores acks"

# 16. PromptSubmit detects bug keywords with CLAUDE.md rules
OUT=$(echo "{\"prompt\":\"fix the broken endpoint\"}" | .claude/hooks/prompt-submit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "5-Step Thinking" && echo "$OUT" | grep -q "No Bandage Fixes" && echo "$OUT" | grep -q "systematic-debugging"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PromptSubmit bug: 5-step + no-bandage + plugin"

# 17. PromptSubmit detects frontend keywords with plugin refs
OUT=$(echo "{\"prompt\":\"update the react component\"}" | .claude/hooks/prompt-submit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "impeccable:frontend-design"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PromptSubmit frontend: impeccable plugin ref"

# 18. PromptSubmit detects feature keywords with TDD + brainstorm
OUT=$(echo "{\"prompt\":\"implement the new endpoint\"}" | .claude/hooks/prompt-submit-context.sh 2>/dev/null)
echo "$OUT" | grep -q "test-driven-development" && echo "$OUT" | grep -q "brainstorming"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "PromptSubmit feature: TDD + brainstorm refs"

# 19. Stop hook emits systemMessage
OUT=$(.claude/hooks/stop-readiness.sh 2>/dev/null)
echo "$OUT" | grep -q "systemMessage"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "Stop hook emits readiness checklist"

# 20. SubagentStop emits systemMessage
OUT=$(.claude/hooks/subagent-stop.sh 2>/dev/null)
echo "$OUT" | grep -q "systemMessage"
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "SubagentStop emits verification reminder"

# 21. Edge case: empty input to pre-edit-guard
echo "{}" | .claude/hooks/pre-edit-guard.sh >/dev/null 2>&1
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "Pre-edit-guard handles empty input"

# 22. Edge case: empty input to post-edit-context
echo "{}" | .claude/hooks/post-edit-context.sh >/dev/null 2>&1
report $([[ $? -eq 0 ]] && echo PASS || echo FAIL) "Post-edit-context handles empty input"

echo ""
echo "=== $PASS/$((PASS+FAIL)) PASS ==="
[[ $FAIL -eq 0 ]] && echo "All checks passed." || echo "$FAIL check(s) FAILED."
'
```

---

## Full Verification (Claude Code Session)

Run in a **fresh Claude Code session** from the project root. These test hooks that only fire inside Claude Code's runtime.

### Test 1: SessionStart

**Trigger:** Session loads automatically.

**Check:** Your first response context should contain a `<system-reminder>` with:
- "Enforcement stack active"
- "Protected directories are read-only"

**Report:** `SESSION_START: PASS/FAIL`

### Test 2: CLAUDE.md

**Ask:** "Read CLAUDE.md and confirm it has all 6 sections"

**Check these sections exist:**
1. `# Project Context` — describes the project
2. `## GLOBAL RULES` — 5-Step Thinking with "Skip for: trivial factual queries"
3. `### 2. No Bandage Fixes` — `# TEMPORARY:` convention
4. `## Coding Conventions` — language, testing, naming
5. `## Proactive Plugin Usage` — lists skill categories
6. `## Git Policy` — commit/push rules

**Report:** `CLAUDE_MD: PASS/FAIL`

### Test 3: PreToolUse Guard (Protected Dir Block)

**Ask:** "Add a comment to vendor/some-lib/index.js"

**Check:** The edit is BLOCKED with reason containing "read-only" or "protected".

**Report:** `PRETOOLUSE_BLOCK: PASS/FAIL`

### Test 4: PostToolUse Context

**Ask:** "Edit a file in your API routes directory, then revert it"

**Check:** After the edit you see a reminder about input validation, auth checks, or status codes.

**Report:** `POSTTOOLUSE: PASS/FAIL`

### Test 5: UserPromptSubmit Context

**Say:** "there is a bug in the user registration flow"

**Check:** Response context includes "reproduce the failure first" or similar bug-workflow guidance.

**Report:** `PROMPT_SUBMIT: PASS/FAIL`

### Test 6: Rules Auto-Load

**Ask:** "What are the rules for [your code area]?"

**Check:** Claude can cite constraints from the matching `.claude/rules/*.md` file without reading it explicitly.

**Report:** `RULES_AUTOLOAD: PASS/FAIL`

### Test 7: Memory Files

**Ask:** "Read the memory index"

**Check:** MEMORY.md index at the project's memory path loads correctly (or doesn't exist yet for new projects — that's OK).

**Report:** `MEMORY: PASS/FAIL`

### Test 8: Stop Hook

**Say:** "I'm done testing"

**Check:** The stop hook fires (status message "Final check...") and emits the 4-point readiness checklist.

**Report:** `STOP_HOOK: PASS/FAIL`

### Summary Template

```
SESSION_START:
CLAUDE_MD:
PRETOOLUSE_BLOCK:
POSTTOOLUSE:
PROMPT_SUBMIT:
RULES_AUTOLOAD:
MEMORY:
STOP_HOOK:

OVERALL: X/8 PASS
```

---

## Architecture Reference

| Hook Phase | Script | Matcher | Behavior |
|---|---|---|---|
| SessionStart | inline JSON | — | Emits project invariants once |
| UserPromptSubmit | `prompt-submit-context.sh` | — | Contextual hints (frontend/bug/feature), silent on acks |
| PreToolUse | `pre-edit-guard.sh` | `Write\|Edit\|MultiEdit` | Blocks protected dirs, warns on DB imports + schema edits |
| PostToolUse | `post-edit-context.sh` | `Write\|Edit\|MultiEdit` | File-class reminders (API, database, frontend, config) |
| Stop | `stop-readiness.sh` | — | 4-point readiness checklist |
| SubagentStop | `subagent-stop.sh` | — | 4-point subagent verification reminder |
