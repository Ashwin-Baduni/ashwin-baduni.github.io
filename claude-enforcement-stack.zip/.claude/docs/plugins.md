# Installed Plugins Reference

Last updated: 2026-03-30

This documents all Claude Code plugins used in this setup. If reinstalling on a fresh machine, install these in order using `/install-plugin` in Claude Code.

---

## Official Marketplace Plugins

These come from the `claude-plugins-official` marketplace (built-in).

### 1. superpowers
- **Install:** `/install-plugin superpowers` (from official marketplace)
- **Source:** claude-plugins-official
- **Version:** 5.0.6
- **What it does:** Core workflow disciplines — brainstorming, planning, TDD, systematic debugging, parallel agent dispatch, git worktrees, code review requests, verification gates.
- **Key skills:**
  - `brainstorming` — structured exploration before implementation
  - `writing-plans` / `executing-plans` — multi-step task planning
  - `test-driven-development` — write failing tests before code
  - `systematic-debugging` — root-cause-first debugging
  - `dispatching-parallel-agents` — parallelize independent tasks
  - `subagent-driven-development` — per-task subagents with review
  - `using-git-worktrees` — isolated feature branches
  - `verification-before-completion` — proof before claims
  - `requesting-code-review` / `receiving-code-review` — review workflows
  - `finishing-a-development-branch` — integration options
  - `writing-skills` — create new skills

### 2. code-review
- **Install:** `/install-plugin code-review` (from official marketplace)
- **Source:** claude-plugins-official
- **What it does:** Reviews pull requests or completed work for bugs, style issues, and missed requirements.
- **Key skills:**
  - `code-review` — comprehensive PR / diff review

### 3. code-simplifier
- **Install:** `/install-plugin code-simplifier` (from official marketplace)
- **Source:** claude-plugins-official
- **Version:** 1.0.0
- **What it does:** Reviews recently changed code for reuse opportunities, quality issues, and efficiency improvements, then fixes them.
- **Key skills:**
  - `simplify` — review and simplify changed code

### 4. feature-dev
- **Install:** `/install-plugin feature-dev` (from official marketplace)
- **Source:** claude-plugins-official
- **What it does:** Guided feature development with codebase understanding, architecture focus, and a structured 7-phase workflow.
- **Key skills:**
  - `feature-dev` — full feature development workflow
- **Key agents:**
  - `code-reviewer` — confidence-based code review
  - `code-architect` — feature architecture design
  - `code-explorer` — deep codebase analysis

### 5. frontend-design
- **Install:** `/install-plugin frontend-design` (from official marketplace)
- **Source:** claude-plugins-official
- **What it does:** Creates production-grade frontend interfaces with high design quality. Avoids generic AI aesthetics.
- **Key skills:**
  - `frontend-design` — distinctive UI implementation

---

## Third-Party Marketplace Plugins

These require adding the marketplace first, then installing the plugin.

### 6. impeccable
- **Marketplace:** `pbakaus/impeccable` (GitHub)
- **Install:**
  1. Add marketplace: In Claude Code settings, add `pbakaus/impeccable` as an extra marketplace (GitHub source)
  2. Install: `/install-plugin impeccable` (from impeccable marketplace)
- **Version:** 1.3.0
- **What it does:** Comprehensive UI quality toolkit — polish, audit, accessibility, animations, responsive design, and more.
- **Key skills:**
  - `frontend-design` — the impeccable version (more opinionated than the official one)
  - `audit` — accessibility, performance, theming, responsive checks
  - `polish` — final quality pass (alignment, spacing, consistency)
  - `critique` — UX effectiveness evaluation
  - `animate` — purposeful micro-interactions
  - `harden` — production resilience (error handling, i18n, overflow)
  - `clarify` — improve UX copy and microcopy
  - `adapt` — cross-device / cross-platform adaptation
  - `optimize` — performance (loading, rendering, bundle size)
  - `distill` — strip to essence, remove complexity
  - `delight` — add personality and joy
  - `onboard` — onboarding flows and empty states
  - `colorize` — add strategic color
  - `extract` — extract reusable components into design system
  - `normalize` — match design system consistency
  - `bolder` / `quieter` — adjust visual intensity
  - `teach-impeccable` — one-time setup for design context

### 7. claude-mem
- **Marketplace:** `thedotmack/claude-mem` (GitHub)
- **Install:**
  1. Add marketplace: In Claude Code settings, add `thedotmack/claude-mem` as an extra marketplace (GitHub source)
  2. Install: `/install-plugin claude-mem` (from thedotmack marketplace)
- **Version:** 10.5.5
- **What it does:** Persistent cross-session memory with MCP search, phased plan execution, and AST-aware code exploration.
- **Key skills:**
  - `make-plan` — create phased implementation plans with doc discovery
  - `do` — execute plans using subagents (one objective per agent)
  - `mem-search` — search persistent memory across sessions
  - `smart-explore` — token-efficient structural code search using tree-sitter AST

---

## Settings Snapshot

To restore plugin configuration in `~/.claude/settings.json`:

```json
{
  "enabledPlugins": {
    "frontend-design@claude-plugins-official": true,
    "superpowers@claude-plugins-official": true,
    "code-review@claude-plugins-official": true,
    "code-simplifier@claude-plugins-official": true,
    "feature-dev@claude-plugins-official": true,
    "impeccable@impeccable": true,
    "claude-mem@thedotmack": true
  },
  "extraKnownMarketplaces": {
    "impeccable": {
      "source": {
        "source": "github",
        "repo": "pbakaus/impeccable"
      }
    },
    "thedotmack": {
      "source": {
        "source": "github",
        "repo": "thedotmack/claude-mem"
      }
    }
  }
}
```

## Install Order

On a fresh machine:
1. Install Claude Code
2. Official plugins (any order): `superpowers`, `code-review`, `code-simplifier`, `feature-dev`, `frontend-design`
3. Add impeccable marketplace, then install `impeccable`
4. Add thedotmack marketplace, then install `claude-mem`
