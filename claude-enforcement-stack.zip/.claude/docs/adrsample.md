Purpose:
  This ADR will be used to drive implementation. It must remove ambiguity, not
  introduce it.

  Writing standard:
  - Be concrete.
  - Be mechanically precise.
  - Prefer explicit constraints over descriptive prose.
  - If something is migration-state only, say so explicitly.
  - If something is final-state only, say so explicitly.
  - Do not speculate beyond what the source docs support.
  - Do not redesign the architecture.
  - Do not invent new major abstractions not already in the docs.
  - Do not soften hard constraints into optional guidance.

  Required structure:
  Use this exact section structure:

  # ADR-XXX: <Short Decision Title>

  - Status:
  - Date:
  - Owners:
  - Deciders:
  - Related Docs:
  - Related ADRs:
  - Supersedes:
  - Superseded By:

  ## 1. Problem Statement
  ## 2. Scope
  ## 3. Non-Goals
  ## 4. Context
  ## 5. Decision Drivers
  ## 6. Decision
  ## 7. Architectural Invariants
  ## 8. Chosen Design
  ### 8.1 Runtime Flow
  ### 8.2 Contracts and Data Shapes
  ### 8.3 State Model
  ### 8.4 Failure and Fallback Semantics
  ### 8.5 Ownership Boundaries
  ### 8.6 Final-State vs Migration-State Notes
  ## 9. Alternatives Considered
  ## 10. Consequences
  ### 10.1 Benefits
  ### 10.2 Costs
  ### 10.3 Tradeoffs Accepted
  ### 10.4 New Complexity Introduced
  ## 11. Safety Analysis
  ### 11.1 Failure Modes
  ### 11.2 Commit / Idempotency Semantics
  ### 11.3 Data Integrity Risks
  ### 11.4 Rollback / Recovery Behavior
  ### 11.5 Observability Requirements
  ## 12. Implementation Plan
  ## 13. Validation Plan
  ### 13.1 Unit Validation
  ### 13.2 Integration Validation
  ### 13.3 Regression Validation
  ### 13.4 Performance Validation
  ### 13.5 Operational Validation
  ## 14. Rollout and Backout
  ## 15. Success Criteria
  ## 16. Risks Remaining
  ## 17. Open Questions
  ## 18. Appendix

  Quality bar for each section

  1. Problem Statement
  - State the exact problem.
  - Must mention current-state drift and why a formal decision is needed.
  - Must not be generic.

  2. Scope
  - State what this ADR decides.
  - State which architecture layers it covers.
  - State which docs it derives from.

  3. Non-Goals
  - Must explicitly exclude at least:
    - changing vendored/protected code
    - redesigning core architecture
    - adding unsupported cross-cutting concerns
  <!-- CUSTOMIZE: Add your project-specific non-goals here -->

  4. Context
  - Summarize current-state facts from source docs only as needed.
  - Keep it factual.
  - No recommendations here.

  5. Decision Drivers
  - Use a flat bullet list.
  - Include at least:
    - correctness
    - migration safety
    - maintainability
    - latency / performance
    - observability
    - backward compatibility

  6. Decision
  - One executive paragraph.
  - Then a short flat bullet list of the core decision points.

  7. Architectural Invariants
  - Write as MUST / MUST NOT.
  - These are hard constraints, not suggestions.
  <!-- CUSTOMIZE: Add your project's hard invariants here -->

  8. Chosen Design
  8.1 Runtime Flow
  - Describe the end-state flow cleanly.
  - Separate phases clearly (preprocessing, execution, commit).
  - Make data flow explicit.

  8.2 Contracts and Data Shapes
  - Name and describe key types/interfaces.
  - Do not dump fake code unless necessary.
  - If you use code-like blocks, keep them short and accurate.

  8.3 State Model
  - Must clearly separate state tiers (durable, session, transient).
  - Must say who reads and who writes each tier.

  8.4 Failure and Fallback Semantics
  - Must explain failure categories (retryable, permanent, user-input, unknown).
  - Must distinguish execution failure from state-commit failure.

  8.5 Ownership Boundaries
  - State who owns each responsibility (routing, planning, execution, emission, commit).

  8.6 Final-State vs Migration-State Notes
  - Must explicitly distinguish final-state behavior from temporary migration shims.

  9. Alternatives Considered
  - Must include rejected alternatives with reasons.

  10. Consequences
  - Must be honest.
  - Include both positive and negative consequences.
  - Mention any complexity cost introduced.

  11. Safety Analysis
  - This section is mandatory and must be strong.
  - It must not be generic "watch for bugs."

  11.1 Failure Modes
  - Enumerate concrete failure cases.

  11.2 Commit / Idempotency Semantics
  - This is especially important.
  - Must explicitly state:
    - emit happens before commit
    - no re-emit on commit retry
    - retry budget
    - async reconciliation path
    - idempotency key semantics

  11.3 Data Integrity Risks
  - Must discuss partial commit and stale state risks.

  11.4 Rollback / Recovery Behavior
  - Must say what happens if rollout fails mid-wave.

  11.5 Observability Requirements
  - Must include telemetry/logging expectations.
  - Must mention commit-failure telemetry.

  12. Implementation Plan
  - Use a phased/wave structure.
  - For each phase:
    - objective
    - key deliverables
    - dependency notes
    - legacy behavior removed in that phase

  13. Validation Plan
  - Must be concrete and testable.
  - Organize by unit, integration, regression, performance, operational.

  14. Rollout and Backout
  - Must explain how to roll out incrementally.
  - Must explain how to back out safely.

  15. Success Criteria
  - Must be measurable where possible.
  - Avoid vague terms like "better" or "cleaner" without observable criteria.

  16. Risks Remaining
  - These should be residual risks after acceptance, not re-listing the whole ADR.

  17. Open Questions
  - Only include if truly unresolved in the docs.
  - Do not invent open questions just to fill the section.

  18. Appendix
  - Optional, but include a short ASCII flow if it helps.
  - If included, it must match the chosen design exactly.

  Style constraints
  - No hype.
  - No marketing tone.
  - No "future-looking visionary" language.
  - No generic software-architecture filler.
  - No nested bullets.
  - Use short flat bullets or short paragraphs.
  - Keep terminology consistent with the docs.
  - If a term is migration-only, label it.
  - If a term is final-state, label it.

  What to avoid
  - Do not turn this into a changelog.
  - Do not restate all source docs verbatim.
  - Do not copy large ASCII blocks unless necessary.
  - Do not create fake certainty where the docs explicitly say "must verify
  empirically."
  - Do not collapse final-state and migration-state behavior together.

  Final quality check before you finish
  The ADR should answer all of these clearly:
  - What exactly are we standardizing?
  - What is the final runtime flow?
  - Who owns each responsibility?
  - What happens on execution failure?
  - What happens when emit succeeds but commit fails?
  - What is final state vs migration-only?
  - What is explicitly out of scope?
  - What do engineers implement first?

  Deliverable
  - Produce only the ADR content.
  - Do not commit anything.
  - Do not modify code unless explicitly asked later.
